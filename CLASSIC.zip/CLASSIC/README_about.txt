-------------------------------------------------------------------------------
About this level pack:

CLASSIC tab is a new custom userlevel tab that replaces the intro tab with 125 new levels. Levels can be played in any order, though as always columns should provide the best experience.

For the first time ever we now have custom leaderboards with native highscoring! 

If you would like to be able to submit your replays to the custom server (and watch others!) then use the folder "Install_Exe"

This project also comes with two new custom palettes: 'classic darkmode' and 'classic lightmode'(my personal edit of Amibe's 'more classic')

-------------------------------------------------------------------------------

* Levels made by NateyPooPoo.

* Guest levels made by:

	abho
	Amibe
	audrey
	DarkStuff
	kkstrong
	Omega
	Sclews
	Skylighter
	Slomac
	SuperVolcano
	VCM
	wolf
	w95559w

* Palettes made by Amibe and NateyPooPoo.

* Game modding by Eddy