This .exe will install the custom tab levels, as well as patch the game into the custom leaderboards.

1)	Double click on the npp_classic.exe in this folder

2)	You will likely get a popup from windows defender. Click "More info", then click "Run anyway".

3)	You will get a popup telling you the pack was installed successfully.


For the leaderboards to display properly you'll need a fresh profile.

1)	Go to C:\Users\(YOUR USER)\Documents\Metanet\N++

2)	Rename or Move nprofile elsewhere


NOTE: Go to "settings" and set level submission to "on", if you'd like your level replays to submit at the end of episodes.


Install palettes manually if desired. Move the "Palettes" folder into your NPP directory:

	C:\SteamLibrary\steamapps\common\N++\NPP


You're good to go!




~~~To uninstall~~

Simply click the .exe again and it will uninstall the custom tab and leaderboards, and reinstate the vanilla version of the game.