~~~~~~~~~~~~~~~~~~~~~~~~~MANUAL INSTALL (includes palettes)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1)	Go to C:\SteamLibrary\steamapps\common\N++\

2)	Drag and drop the NPP folder from CLASSIC to the N++ directory

3)	Click "replace" when prompted

To Uninstall:

4)	Use the NPP folder located in the "backup" folder of CLASSIC, repeat the above steps (palettes will remain until manually deleted)



It's reccomended that you play with a fresh save file to better track your progress. This is optional, however.

1)	Go to C:\Users\(YOUR USER)\Documents\Metanet\N++

2)	Rename or Move nprofile elsewhere
	(To be put back afterwards)


-------------------------------------------------------------------------------

Once you've finished, start up N++ and head to intro, which has been replaced with the new content.

If you lose (or choose not to backup) the original level files, they can be found in this folder as well.

-------------------------------------------------------------------------------