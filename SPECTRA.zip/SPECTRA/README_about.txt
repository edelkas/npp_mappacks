-------------------------------------------------------------------------------
About this level pack:

SPECTRA tab is an intro tab replacement, with levels featuring organic yet tight-knit design.
Play by column for best experience ;)

Also comes with two palettes made by us: 'cyberware' and 'ultraviolet'.

-------------------------------------------------------------------------------

* Levels made by MegalordX8 and abho.

* Guest levels made by NateyPooPoo and frost.

* Game modding by Eddy