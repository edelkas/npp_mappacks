~~~~~~~~~~~~~~~~~~~~~~~~~QUICK INSTALL~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1)	Run the executable 'spectra.exe'. 

(If an error comes up about admin perms, try running the exe by right clicking -> 'Run as administrator')

2)	That's it! Run it again to uninstall the tab.



-------------------------------------------------------------------------------

Once you've finished, start up N++ and head to intro, which has been replaced with the new content.

-------------------------------------------------------------------------------