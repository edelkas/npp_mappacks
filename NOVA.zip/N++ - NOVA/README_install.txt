-------------------------------------------------------------------------------

AUTOMATIC INSTALLER (added by Eddy)

In order to install the mappack, simply run the installer file, npp_nova.exe.
It will take care of everything, including swapping the map files & savefile,
patching the game to get custom leaderboards, and installing the custom palettes.

To uninstall, run the installer again.

Notes:

  1) You may have to grant permission to Defender to use the installer. If you
     have problems doing so, don't hesitate to ask in the Discord.

  2) You can't have multiple mappacks installed. If you do, you'll have to
     uninstall that one first before using this one.

-------------------------------------------------------------------------------



MANUAL INSTALLING

How to play:

1) 	Download SI.txt

2)	Go to C:\SteamLibrary\steamapps\common\N++\NPP\Levels

3)	Move the existing SI.txt elsewhere
	(To be put back in this folder when you want to switch back to vanilla)

4)	Move the downloaded files to this folder


It's reccomended that you play with a fresh save file to better track your progress. This is optional, however.

1)	Go to C:\Users\(YOUR USER)\Documents\Metanet\N++

2)	Move nprofile elsewhere
	(To be put back afterwards)

-------------------------------------------------------------------------------

Once you've finished, start up N++ and head to intro, which has been replaced with the new content.

If you lose (or choose not to backup) the original level files, they can be found in this folder as well.

-------------------------------------------------------------------------------

How to install custom palettes:

1) Go to C:\SteamLibrary\steamapps\common\N++\NPP

2) If you do not have a folder named 'Palettes':
	
	2.1) Download the palettes folder from the drive.

	2.2) Place the folder in the directory.

	2.3) You're good to go!

3) If you do:

	3.1) Download nova cosmic and nova orbit from the drive (the folders)

	3.2) Place the downloaded folders in the 'Palettes' folder.

	3.3) You're good to go!