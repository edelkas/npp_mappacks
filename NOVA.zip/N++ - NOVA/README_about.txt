-------------------------------------------------------------------------------
About this level pack:

NOVA tab is a new custom userlevel tab that replaces the intro tab with 125 new levels.

The levels are intended to be played in column order, though we know some of you don't listen ;)

This tab also comes with two custom palettes, 'nova cosmic' and 'nova orbit'.

Also try NEOMETA, NITRO, and CLEVER!

-------------------------------------------------------------------------------

* Levels made by abho and NateyPooPoo.

* Palettes made by Emmoji and NateyPooPoo.

* Game modding by Eddy