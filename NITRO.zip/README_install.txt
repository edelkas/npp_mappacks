AUTOMATIC INSTALLATION (added by Eddy)

Run the installer, npp_nitro.exe. This will automatically:

- Add the pack's levels to your game.
- Patch your game to obtain custom leaderboard access.
- Swap your savefile.

Among other things. To uninstall, re-run the installer.

-------------------------------------------------------------------------------

MANUAL INSTALLATION

How to play:

1) 	Download SI.txt and S.txt

2)	Go to C:\SteamLibrary\steamapps\common\N++\NPP\Levels

3)	Move the existing SI.txt and S.txt elsewhere
	(To be put back in this folder when you want to switch back to vanilla)

4)	Move the downloaded files to this folder


It's reccomended that you play with a fresh save file to better track your progress. This is optional, however.

1)	Go to C:\Users\(YOUR USER)\Documents\Metanet\N++

2)	Move nprofile elsewhere
	(To be put back afterwards)

-------------------------------------------------------------------------------

Once you've finished, start up N++ and head to the intro and N++ tab, which have been replaced with the new content.

If you lose (or choose not to backup) the original level files, they can be found in this folder as well.

-------------------------------------------------------------------------------