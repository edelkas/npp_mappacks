-------------------------------------------------------------------------------
About this level pack:


Nitro tab is a new custom userlevel tab that replaces the intro tab with 125 new levels, including some special episodes. It also replaces the N++ tab with 15 secret levels.


I reccomend that you play by column, as this is the order which I intended.

I hope you enjoy the tab! If you do, also try 'NEOMETA'.

-------------------------------------------------------------------------------

* Levels made by abho

* Guest apperances: aloading444, NateyPooPoo, Ham, DarkStuff, ekisacik

* Special collab appearance: sclews

* Game modding by Eddy