About this level pack:

REDUX is a challenge-focused reimagining of the Legacy Tab in N++. This pack builds upon and alters
the first 150 Legacy levels to include challenges in the GTOCE format. The levels are designed to
be played in column-order, ending with X-row.

This pack replaces the N++ Tab and includes a custom tab file, secrets file, and nprofile with base
completion in Intro Tab and the first five rows of the N++ Tab. For help installing these files,
navigate to the README_install.txt provided with the pack.

With the custom save enabled, players can access the X-row levels and view challenges after earning
all-gold in 25 episodes. Secrets are also listed in REDUX_Challenges.txt.


----------------------------------------------------------------------------------------------------

FAQ:

Does this pack have custom leaderboards?
	No. The pack does not make many significant tweaks to the highscoring routes of the original
	Legacy levels, so we decided against having leaderboards.

Do I have to use the custom profile?
	You may start from a fresh save if you prefer. The pack comes with a secondary file (S2.txt)
	which places the X-row levels in the first column of the Ultimate Tab, allowing them to be
	played. Challenges can be found in the accompanying REDUX_Challenges.txt.

How many challenges/points are there?
	There are 365 challenges in total, resulting in a max Solo Score of 1150 if using the custom
	profile, or 695 if starting from a fresh save with the secondary X-row file. This includes
	base completion, all-gold, challenges, and deathless episodes.

What about the rest of the tab?
	Uh, get back to us in a few months!


----------------------------------------------------------------------------------------------------

Credits and special thanks:

* WheatyTruffles — level creation, playtesting
* DarkStuff — level creation, playtesting
* w95559w — playtesting
* Blizzy — playtesting
* abho — publishing
* Eddy — game modding

We also recommend playing Murat's Legacy Challenges — they implement unique rules and restrictions
to put a fresh spin on the Legacy Tab:
https://docs.google.com/spreadsheets/d/1ZlZu3T8fQtYcV18RJPVbK764bgpAr62OSOYs3qUIQLs/edit?usp=sharing
