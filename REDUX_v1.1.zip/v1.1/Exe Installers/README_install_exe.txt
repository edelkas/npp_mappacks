The application "npp_redux.exe" will install the custom level files and secret files for REDUX, as 
well as the custom nprofile. The following steps detail its use:

	1) When you download or run this file, you will likely get a notification from Windows 
	Defender or a separate antivirus software. You may have to navigate a popup window, 
	selecting the option to "Run anyway," or set a parameter for your antivirus to allow 
	this software on your computer.

	2) Running the installer will save your original profile in C:\Users\(YOUR USER)\Documents
	\Metanet\N++, under nprofile_original.zip. 

	3) Running the .exe again will uninstall the tab, restoring the vanilla game files along 
	with your original save data. Your REDUX profile will be saved under nprofile_rdx.zip.

	4) From there, any further installs and uninstalls will zip and unzip the corresponding 
	files, so that both are automatically kept up to date in zipped fashion.

	5) We recommend manually backing up your nprofiles whenever possible, to be safe.


If you have manually installed the tab, DO NOT USE THIS APPLICATION until you have uninstalled it 
manually. To carry over an existing REDUX save, follow these steps:

	1) Uninstall the pack manually. Be sure to restore the level files as well as your original
	nprofile.

	2) Zip your existing REDUX profile into a folder named "nprofile_rdx.zip" and ensure to 
	place it in C:\Users\(YOUR USER)\Documents\Metanet\N++.

	3) You may now run the installer/uninstaller normally.


If you wish to manually manage your nprofile, you may use the application "npp_redux_nosave.exe"
instead, which installs/uninstalls the tab files and nothing else.

Please contact Eddy if you run into any problems with either installer.


----------------------------------------------------------------------------------------------------

Remember to LAUNCH STEAM IN OFFLINE MODE when you play this pack! Playing online poses a risk of 
submitting scores that do not match the vanilla campaign.

This pack does not contain custom leaderboards.