This pack comes with a level file (S.txt), secrets file (Scodes.txt), and custom profile (nprofile). 
Once you have downloaded all three files, you can follow these steps to play:

	1) Go to C:\SteamLibrary\steamapps\common\N++\NPP\Levels

	2) Move the vanilla S.txt and Scodes.txt elsewhere. Backups have been included if you happen 
	to misplace these files.

	3) Move the custom S.txt and Scodes.txt to this folder.


To install the custom profile:

	1) Go to C:\Users\(YOUR USER)\Documents\Metanet\N++

	2) Move your nprofile elsewhere — back it up in multiple places, to be safe!

	3) Replace it with the custom nprofile. If it worked, you should have 625 Solo/Total Score 
	on the Profile>Progress screen.

	4) *Save this nprofile somewhere when you're done with the pack!* We plan on creating more 
	REDUX levels in the future, and you will be able to carry your save file over between each 
	new installment.


----------------------------------------------------------------------------------------------------

We recommend using the custom profile to view challenges and track your progress throughout future 
installments of REDUX. However, if you wish to start from a fresh save, you can use the "X-Row Alt 
Files" included with the pack to access the X-row levels in Ultimate Tab:

	1) Go to C:\SteamLibrary\steamapps\common\N++\NPP\Levels

	2) Move the vanilla S2.txt and S2codes.txt elsewhere. Backups have been included if you 
	happen to misplace these files.

	3) Move the custom S2.txt and S2codes.txt to this folder.


----------------------------------------------------------------------------------------------------

Remember to LAUNCH STEAM IN OFFLINE MODE when you play this pack! Playing online poses a risk of 
submitting scores that do not match the vanilla campaign.

This pack does not contain custom leaderboards.
