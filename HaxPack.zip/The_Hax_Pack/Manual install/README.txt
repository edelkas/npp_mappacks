To manually install the pack, start by navigating to the following folder:

Windows - C:\SteamLibrary\steamapps\common\N++\NPP\Levels
Mac - ~/Library/Application Support/Steam/steamapps/common/N++/N++/Contents/Resources/NPP/Levels
(Note that the /Library folder is hidden on Mac by default.  It can easily be found by choosing the Go menu in the Finder and pressing alt/option.  You'll then see the Library option appear.)
Linux - ~/.steam/steam/steamapps/common/N++/NPP/Levels

Once there, replace the SI.txt file found within with the SI.txt file found in this download.  Next time you load N++, you will find that the in game Intro Tab has been replaced by the Hax Pack!  Don't worry, we've made a copy of the original SI file for you - it can be found in the Backup folder.  If you ever want to return to the original Intro Tab, just replace our SI file with the one found there.

For the best possible experience, we recommend you make a backup copy of your existing nprofile (see below for the location), and start a fresh one for the purporses of playing our pack.  This will allow the game to keep track of your Hax Pack progress for you.

nprofile location:

Windows - C:\Users\USERNAME\Documents\Metanet\N++
Mac - ~/Documents/Metanet/N++/nprofile
Linux - ~/.local/share/Metanet/N++/nprofile