Welcome to the Hax Pack!  This pack consists of 125 levels, with many many hours poured into its creation and organisation.

To install the pack, you have 2 options:

- For Windows, execute the installer found in the "Installer" folder. It's done! If you already have a mappack installed, you'll need to uninstall it first. This method also provides custom highscore leaderboards.

- For anything else, or in Windows if the installer doesn't work, navigate to the "Manual install" folder and follow the instructions there. This method does not provide the custom highscore leaderboards.

Thanks for playing, and we hope you enjoy!  If you have any questions or need any help, please feel free to ask us,

HamSandwich, lord_day, RandomDigits123, yahoozy

With special thanks to donfuy, Eddy, Kostucha, PALEMOON, sept and spiltmilk for their help and contributions.  We also thank jasdanu, lifdoff, OutrightOJ and trance for their help and feedback.