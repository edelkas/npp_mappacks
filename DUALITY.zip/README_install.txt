Option 1: Manual install (No scoreboard functionality, compatible with non overlapping pack)

1) 	Download C.txt and C2.txt

2)	Go to C:\SteamLibrary\steamapps\common\N++\NPP\Levels

3)	Move the existing C.txt and C2.txt elsewhere
	(To be put back in this folder when you want to switch back to vanilla)

4)	Move the downloaded files to this folder

5)	Locate and go to `keys.vars` file within C:\Users\(YOUR USER)\Documents\Metanet\N++

6)	changes the following input for player 2 to be the same as player 1:
	- left
	- right
	- jump
	- alt2 (suicide)


Option 2: Installer (Comes with scoreboard, cannot co-exist with other pack with scoreboard)

0)	Ensure other packs with scoreboard functionality are uninstalled.

2)	Run the installer included within zip (you may have to allow the installer to bypass antivirus)


It's reccomended that you play with a fresh save file to better track your progress. This is optional, however.

1)	Go to C:\Users\(YOUR USER)\Documents\Metanet\N++

2)	Move nprofile elsewhere
	(To be put back afterwards)

-------------------------------------------------------------------------------

IMPORTANT!!!
You need to launch N++ in offline mode on steam when you play the tab. This is because there is a risk of submitting scores that do not match the vanilla campaign.

Once you've finished, start up N++ and head to intro, which has been replaced with the new content.

If you lose (or choose not to backup) the original level files, they can be found in this folder as well.

-------------------------------------------------------------------------------