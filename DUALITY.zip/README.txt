-------------------------------------------------------------------------------
About this level pack:


Duality tab is a new custom userlevel tab that replaces the coop n++ tab with
75 new levels and 5 bonus levels (Episode C-A-03).
This tab features controlling two ninjas with the same input, expanding on the
possibility to play the game you know and loved!

This tab includes a scoreboard with replay for normal playthrough, as well as
an additional least gold count board found only within outte (shoutout to Eddy!).

-------------------------------------------------------------------------------
FAQ:

I play on controller, what do I do?
- During the making of the tab, I did not consider that controller player's
  input are different than that of mouse and keyboard. You may have to look
  into using a key mapper program to sync the input of both your ninjas.

Where's the least gold count board?
- It is within outte only. Try "g-- scores for duaca00" to see for yourself!

Can I play this pack with other pack installed?
- Yes and no. You can manual install this pack without the installer, which
  allow you to play the level without the scoreboard functionality. In general,
  there can be a maximum of 1 pack with scoreboard functionality, but there can
  be multiple other packs without the scoreboard functionality.

Linux installer?
- Ask eddy for tweak

-------------------------------------------------------------------------------

* Levels made by w95559w

* Playtesting by aloading444, doomscroller, NateyPooPoo

* Publishing by abho

* Game modding by Eddy