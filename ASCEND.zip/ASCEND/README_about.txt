-------------------------------------------------------------------------------
About this level pack:

ASCEND tab is a new custom userlevel tab that replaces the intro tab with 125 new levels. Play by columns, rows, whatever you want.  Difficulty increases diagonally.

This project also comes with two new custom palettes: 'ascend zenith', 'ascend summit'.

-------------------------------------------------------------------------------

* Levels made by kkstrong.

* Guest levels made by abho, audrey, SV, Natey, DS, Kostucha, and w95559w

* Game modding by Eddy