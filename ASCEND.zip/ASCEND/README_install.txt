~~~~~~~~~~~~~~~~~~~~~~~~~QUICK INSTALL~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1)	Go to C:\SteamLibrary\steamapps\common\N++\

2)	Drag and drop the NPP folder from ASCEND to the N++ directory

3)	Click "replace" when prompted

To Uninstall:

4)	Use the NPP folder located in the "backup" folder of ASCEND, repeat the above steps (palettes will remain until manually deleted)



It's reccomended that you play with a fresh save file to better track your progress. This is optional, however.

1)	Go to C:\Users\(YOUR USER)\Documents\Metanet\N++

2)	Move nprofile elsewhere
	(To be put back afterwards)







~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~MANUAL INSTALL (by abho)~~~~~~~~~~~~~~~~~~~~~~~~~

How to play:

1) 	Download SI.txt and S.txt

2)	Go to C:\SteamLibrary\steamapps\common\N++\NPP\Levels

3)	Move the existing SI.txt and S.txt elsewhere
	(To be put back in this folder when you want to switch back to vanilla)

4)	Move the downloaded files to this folder


It's reccomended that you play with a fresh save file to better track your progress. This is optional, however.

1)	Go to C:\Users\(YOUR USER)\Documents\Metanet\N++

2)	Move nprofile elsewhere
	(To be put back afterwards)


-------------------------------------------------------------------------------

Once you've finished, start up N++ and head to intro, which has been replaced with the new content.

If you lose (or choose not to backup) the original level files, they can be found in this folder as well.

-------------------------------------------------------------------------------

How to install custom palettes:

1) Go to C:\SteamLibrary\steamapps\common\N++\NPP

2) If you do not have a folder named 'Palettes':
	
	2.1) Download the palettes folder from the drive.

	2.2) Place the folder in the directory.

	2.3) You're good to go!

3) If you do:

	3.1) Download ascend zenith and ascend summit from the drive (the folders)

	3.2) Place the downloaded folders in the 'Palettes' folder.

	3.3) You're good to go!