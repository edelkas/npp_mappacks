-------------------------------------------------------------------------------

AUTOMATIC INSTALLER (added by Eddy)

In order to install the mappack, simply run the installer file, npp_neometa.exe.
It will take care of everything, including swapping the map files & savefile,
patching the game to get custom leaderboards, and more.

The new levels with now be in Intro tab. To uninstall, run the installer again.

There are optionally challenges as well. For this, read the manual installation
instructions down below.

Notes:

  1) You may have to grant permission to Defender to use the installer. If you
     have problems doing so, don't hesitate to ask in the Discord.

  2) You can't have multiple mappacks installed. If you do, you'll have to
     uninstall that one first before using this one.

-------------------------------------------------------------------------------


MANUAL INSTALLING

How to play:

1) 	Download S.txt and Scodes.txt

2)	Go to C:\SteamLibrary\steamapps\common\N++\NPP\Levels

3)	Move the existing S.txt and Scodes.txt elsewhere
	(To be put back in this folder when you want to switch back to vanilla)

4)	Move the downloaded files to this folder


It's reccomended that you play with a fresh save file to better track your progress. This is optional, however.

1)	Go to C:\Users\(YOUR USER)\Documents\Metanet\N++

2)	Move nprofile elsewhere
	(To be put back afterwards)

-------------------------------------------------------------------------------

Once you've finished, start up N++ and head to the N++ tab, which has been replaced with the new content.

If you lose (or choose not to backup) the original level files, they can be found in this folder as well.

Keep in mind that the secret challenges are not supported in the pack due to game limitations. Instead, they're listed in challenges.txt if you wish to attempt them.

-------------------------------------------------------------------------------

* Levels made by abho

* Game modding by Eddy